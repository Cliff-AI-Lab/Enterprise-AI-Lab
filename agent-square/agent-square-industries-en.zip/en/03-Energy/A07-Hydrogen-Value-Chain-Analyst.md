---
name: 氢能全链路分析
name_en: Hydrogen Value Chain Analyst
type: Composite Application
industry: Energy
composed_of: [新能源投研员, 碳排放分析师, 供应链策略师]
apis: [EIA, NREL, Carbon Interface]
emoji: 💧
---

# 💧 氢能全链路分析 Hydrogen Value Chain Analyst

## Use Case
投资机构/氢能企业的制-储-运-加-用全链路成本模型和项目可行性分析。

## Agent Composition
```
[新能源投研员] → 制氢技术路线
[碳排放分析师] → 蓝氢/绿氢碳强度
[供应链策略师] → 运输/储存方案
```

## Bound APIs
| API | Purpose |
|-----|------|
| EIA | 能源价格 |
| NREL | 氢能研究数据 |
| Carbon Interface | 碳排查 |

## 核心工作流
1. **制氢技术**：PEM/ALK/SOEC 对比
2. **原料价**：电价/气价/煤价
3. **运输方式**：气态/液态/管道/LOHC
4. **应用场景**：交通/冶金/化工
5. **经济性**：LCOH $/kg

## Sample Output
```
【某省 绿氢项目可研】
规模: 10,000 Nm³/h (年产7,300吨)
电解水技术: PEM (高效灵活)
配套可再生电源: 风光200MW
关键指标:
  - 产氢能耗: 48 kWh/kg
  - 电价 ¥0.30/kWh (自发+平价购电)
  - 折旧/维护 ¥4/kg
  - LCOH: ¥18.4/kg
应用匹配:
  - 1/3 卖给钢厂 (替代焦炭)
  - 1/3 卖给甲醇厂 (CO2加氢)
  - 1/3 建加氢站 (重卡)
与灰氢比(¥12/kg): 溢价 54%
但:
  - CBAM钢铁: 灰氢含碳成本 +¥6/kg → 绿氢具有竞争力
  - 政策补贴: ¥5/kg → 持平
结论: 项目可行, IRR 11.2% (15年)
```
