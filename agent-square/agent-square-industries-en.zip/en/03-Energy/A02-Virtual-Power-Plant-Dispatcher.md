---
name: 虚拟电厂调度
name_en: Virtual Power Plant Dispatcher
type: Composite Application
industry: Energy
composed_of: [电力负荷预测员, 能效审计师, 数据采集工程师]
apis: [EIA, ThingSpeak, OpenWeatherMap]
emoji: ⚡
---

# ⚡ 虚拟电厂调度 Virtual Power Plant Dispatcher

## Use Case
聚合分布式光伏+储能+可调负荷，响应电网调峰/辅助服务，获取补贴收益。

## Agent Composition
```
[数据采集工程师] → 终端资源接入
[电力负荷预测员] → 可用容量预测
[能效审计师] → 需求响应潜力
```

## Bound APIs
| API | Purpose |
|-----|------|
| EIA | 电力市场数据 |
| ThingSpeak | 终端资源数据流 |
| OpenWeatherMap | 光/风发电预测 |

## 核心工作流
1. **资源聚合**：工商业用户接入
2. **潜力测算**：可调节容量
3. **市场投标**：日前/实时
4. **调度执行**：指令分发
5. **结算分成**：用户分享收益

## Sample Output
```
【虚拟电厂运营月报 2026-04】
聚合资源:
  - 光伏分布式 48MW
  - 工商业储能 22MWh
  - 可调负荷 35MW
  - 充电桩 1,200把 (320MW峰)
月度调度:
  - 调峰响应 12次 (尖峰时段)
  - 平均响应容量 68MW (用户85%可靠)
  - 累计削峰 3,200 MWh
收益:
  - 调峰补贴: ¥480万
  - 辅助服务: ¥92万
  - 合计 ¥572万
分成后:
  - 聚合商留存 30% ¥172万
  - 终端用户分享 70% ¥400万
```
