---
name: 大宗商品套利员
name_en: Commodity Arbitrage Trader
type: Composite Application
industry: Finance
composed_of: [股票分析师, 外汇交易助手, 投资组合管理师]
apis: [Alpha Vantage, CoinGecko, ExchangeRate-API]
emoji: 🛢️
---

# 🛢️ 大宗商品套利员 Commodity Arbitrage Trader

## Use Case
金属/能源/农产品的跨市场(内外盘)/跨期/跨品种套利。

## Agent Composition
```
[股票分析师] → 期货合约基本面
[外汇交易助手] → 内外盘汇率换算
[投资组合管理师] → 对冲头寸管理
```

## Bound APIs
| API | Purpose |
|-----|------|
| Alpha Vantage Commodities | 原油/黄金/铜 |
| ExchangeRate-API | USD/CNY实时汇率 |
| EIA | 能源库存 |

## 核心工作流
1. **价差监控**：LME vs SHFE 铜
2. **汇率因素**：CFR→人民币
3. **套利测算**：扣除仓储+运费+关税
4. **信号触发**：价差>阈值
5. **对冲下单**：两边开仓

## Sample Output
```
【沪铜-LME铜 套利监控 2026-04-17】
LME铜: $9,250/t (人民币 ¥66,950)
SHFE铜2605: ¥67,820/t
理论比价: 1.082 | 实际: 1.094 (溢价)
扣费后价差: ¥380/t (手续费/融资/运输)
信号: 做空SHFE + 做多LME, 等回归
历史赢率: 72% | 平均持有 18天
建议仓位: 30手/side (单边保证金~¥120万)
```
