---
name: 数字孪生城市
name_en: Digital Twin City
type: Composite Application
industry: Technology
apis: [Mapbox, OpenStreetMap, ThingSpeak]
emoji: 🏙️
---

# 🏙️ 数字孪生城市

## Use Case
省市级数字孪生平台: BIM+GIS+IoT融合的城市级3D底座。

## Sample Output
```
【某市数字孪生 进展】
覆盖面积: 380km² 主城区
数据接入:
  - 建筑BIM 180万栋
  - 道路/管廊 GIS全覆盖
  - IoT传感器 20万个
  - 视频监控 80万路
应用场景:
  - 规划仿真
  - 防汛抢险
  - 交通调度
  - 低空经济(eVTOL路径)
性能:
  - Web端加载 5秒内
  - VR漫游流畅
```
