---
name: 智能家居生态
name_en: Smart Home Ecosystem
type: Composite Application
industry: Manufacturing
apis: [ThingSpeak, HiveMQ, HuggingFace]
emoji: 🏠
---

# 🏠 智能家居生态

## Use Case
Matter/HomeKit/米家等互通生态的设备接入+场景联动+语音。

## Sample Output
```
【某生态 年度】
接入设备: 6.2亿 (全球)
品类: 灯/开关/家电/安防/娱乐 680品类
场景联动: 月使用 42亿次
语音交互: 月18亿次
生态伙伴: 3,200家
月活用户: 3.2亿
```
