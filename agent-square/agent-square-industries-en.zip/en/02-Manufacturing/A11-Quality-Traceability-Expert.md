---
name: 质量追溯专家
name_en: Quality Traceability Expert
type: Composite Application
industry: Manufacturing
composed_of: [质量检测员, 数据采集工程师, 供应链策略师]
apis: [JSONBin, QRServer, ThingSpeak]
emoji: 🔎
---

# 🔎 质量追溯专家 Quality Traceability Expert

## Use Case
全生命周期质量追溯：从原料批次→制程参数→成品→客户，一键回溯。汽车/食品/医疗器械必备。

## Agent Composition
```
[质量检测员] → 制程SPC数据
[数据采集工程师] → 批次绑定
[供应链策略师] → 原料溯源
```

## Bound APIs
| API | Purpose |
|-----|------|
| QRServer | 二维码/条码 |
| JSONBin | 追溯记录存储 |
| ThingSpeak | 制程参数绑定 |

## 核心工作流
1. **原料入库**：批次号+供应商
2. **制程绑定**：工单关联参数
3. **成品出厂**：序列号+追溯码
4. **市场反馈**：客诉→反推批次
5. **风险隔离**：波及产品冻结

## Sample Output
```
【客诉追溯 - 客户反馈异响3起】
产品型号: XC-2024 批号 240315
追溯分析:
  成品日期: 2026-03-15
  装配线: 线2 | 班次: 夜班
  关键零件:
    - 轴承 供应商A 批号AB-312
    - 电机 供应商B 批号MB-098
制程数据异常排查:
  - 扭矩参数曲线存在偏高: 85-95 N·m (规范80±5)
  - 同批次生产480件, 已销售356件
预警措施:
  1. 冻结未售124件 + 重新检测
  2. 已售356件 → 主动召回通知
  3. 供应商A复现测试: 同批轴承硬度HRC58.9 (偏低1)
  4. 工艺参数锁死上限
损失估算: ¥320万 (保修+召回物流)
```
