---
name: 数字孪生构建师
name_en: Digital Twin Builder
type: Composite Application
industry: Manufacturing
composed_of: [数据采集工程师, 设备运维工程师, 工艺优化师]
apis: [ThingSpeak, Mapbox, QuickChart]
emoji: 👯
---

# 👯 数字孪生构建师 Digital Twin Builder

## Use Case
为工厂/产线构建3D可视数字孪生，支持仿真/优化/培训。

## Agent Composition
```
[数据采集工程师] → 实时数据接入
[设备运维工程师] → 设备状态映射
[工艺优化师] → 仿真参数调优
```

## Bound APIs
| API | Purpose |
|-----|------|
| ThingSpeak | 实时数据流 |
| Mapbox Static | 园区2D底图 |
| QuickChart | KPI图表 |

## 核心工作流
1. **3D建模**：CAD/BIM导入
2. **数据绑定**：资产ID↔传感器
3. **实时同步**：数字镜像
4. **仿真**：what-if分析
5. **应用**：培训/远程诊断

## Sample Output
```
【某工厂孪生项目验收】
覆盖:
  - 厂区3D模型 (18,000㎡)
  - 关键设备 138台实时状态
  - 物流路径 + AGV实时位置
应用场景落地:
  1. 新员工培训 (减少70%现场时间)
  2. 远程专家诊断 (跨境工厂支援)
  3. 布局优化仿真 (拟新增2条线)
  4. 应急演练 (火灾疏散)
技术栈: Unity + MQTT + WebGL
ROI: 效率提升 12% + 事故率降 35%
用户: 厂长/运维/HR 230+人日活
```
