---
name: 家电售后IoT
name_en: Home Appliance IoT Service
type: Composite Application
industry: Manufacturing
apis: [ThingSpeak, AfterShip]
emoji: 🔧
---

# 🔧 家电售后IoT

## Use Case
白电/厨电的IoT联网 + 预测性维护 + 主动服务。

## Core Capabilities
- 设备状态远程监控
- 故障主动预警
- 上门维修调度
- 滤芯耗材复购

## Sample Output
```
【某家电品牌 售后 月度】
联网设备: 480万 | 月活 312万
主动服务:
  - 故障预警 38,000 (用户端)
  - 主动上门维修 12,800
  - 维修满意度 4.7/5
耗材订阅:
  - 滤芯自动复购 48万单/月
  - 客单 ¥128 | LTV ¥2,400
```
