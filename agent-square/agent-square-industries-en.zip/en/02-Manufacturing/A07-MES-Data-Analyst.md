---
name: MES数据分析师
name_en: MES Data Analyst
type: Composite Application
industry: Manufacturing
composed_of: [数据采集工程师, 生产排程员, 质量检测员]
apis: [ThingSpeak, JSONBin, QuickChart]
emoji: 📊
---

# 📊 MES数据分析师 MES Data Analyst

## Use Case
从MES系统沉淀的生产/质量数据中挖掘隐藏规律，支持持续改善。

## Agent Composition
```
[数据采集工程师] → MES数据清洗
[质量检测员] → SPC + Cpk
[生产排程员] → 延期根因
```

## Bound APIs
| API | Purpose |
|-----|------|
| JSONBin | 配置/报表存储 |
| QuickChart | SPC图/直方图 |
| Abstract Data Validation | 数据质量 |

## 核心工作流
1. **数据提取**：ERP+MES+QMS
2. **多维分析**：人机料法环
3. **关联分析**：指标间因果
4. **异常诊断**：5 Why
5. **报告输出**：每周分析会

## Sample Output
```
【周生产分析会材料 - W16】
产量: 28.4万件 vs 计划 29万件 (达成98%)
合格率: 99.45% (↓0.15pp)
下降根因 (关联分析):
  主因 = 新采购X品牌原料 批次波动 (占65%)
  次因 = 三班组操作员6号离职新手替代
整改:
  - 和供应商开SPC联动 + 抽检加密
  - 新人第一周双人作业
延期订单分析:
  - 80%延期由同一工位(喷涂线)引起
  - 该工位OEE 68% << 厂均85%
  - 本季度重点改善项
```
