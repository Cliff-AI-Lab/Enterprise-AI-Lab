---
name: 中药材种植
name_en: TCM Herbs Farming
type: Composite Application
industry: Agriculture
apis: [OpenWeatherMap, Agro API]
emoji: 🌿
---

# 🌿 中药材种植

## Use Case
人参/当归/三七等道地药材的GAP种植+加工+药典溯源。

## Sample Output
```
【道地药材基地 年度】
种植面积: 28万亩
主营: 人参/当归/三七
GAP认证: 100%
标准:
  - 农残重金属全合格
  - 有效成分≥药典
收益:
  - 人参 单亩 ¥18,000
  - 三七 单亩 ¥12,000
  - 当归 单亩 ¥6,000
带动农户: 12,000户
```
