---
name: 种植金融
name_en: Agricultural Finance Platform
type: Composite Application
industry: Agriculture
composed_of: [农业保险定损员, 贷款评估师, 农产品行情分析师]
source_refs: [Loan Officer Assistant, Financial Analyst]
apis: [Agro API, OpenWeatherMap, ExchangeRate-API]
emoji: 💰
---

# 💰 种植金融 Agricultural Finance Platform

## Use Case
面向种植大户的贷款+保险+担保+远期收购一站式金融服务。

## Agent Composition
```
[农业保险定损员] → 保险捆绑
[贷款评估师] → 信贷审批
[农产品行情分析师] → 还款能力评估
```

## Bound APIs
| API | Purpose |
|-----|------|
| OpenWeatherMap Agro | 地块资料 |
| Alpha Vantage | 农产品价格 |
| ExchangeRate-API | 出口收汇 |

## 核心工作流
1. **农户建档**：土地+经营
2. **信用评估**：生产+历史+保险
3. **产品匹配**：春耕贷/秋收贷
4. **保险捆绑**：价格/气象险
5. **订单收购**：期货锁价

## Sample Output
```
【某种粮大户 综合金融方案】
农户: 张大哥 | 流转土地 800亩 | 种玉米
授信方案:
  - 春耕贷 ¥80万 (买种肥+机)
  - 利率 LPR+50BP = 4.45%
  - 期限 9个月 (10月秋收还)
保险捆绑:
  - 种植险 (气象+病虫) 保额 ¥640万
  - 价格险 (跌破 ¥2,400/吨 补偿)
订单收购:
  - 某粮油企业锁价 ¥2,550/吨
  - 提前收购90%产量
综合效益:
  - 保本价 ¥2,300/吨
  - 预期售价 ¥2,550 ✅
  - 预计净利 ¥48万/800亩
金融机构风险:
  - 坏账率 0.3% (有保险+订单)
```
