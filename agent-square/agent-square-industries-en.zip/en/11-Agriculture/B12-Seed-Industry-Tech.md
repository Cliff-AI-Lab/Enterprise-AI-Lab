---
name: 种子种业科技
name_en: Seed Industry Tech
type: Composite Application
industry: Agriculture
apis: [HuggingFace, Agro API]
emoji: 🌱
---

# 🌱 种子种业科技

## Use Case
商业化育种: 传统杂交+分子标记+基因编辑的新品种研发。

## Sample Output
```
【种业公司 年度】
主营作物: 玉米/水稻/小麦/大豆
育种:
  - 核心种质 5,800份
  - 年配组 42,000个
  - 新品种审定 12个
基因编辑:
  - CRISPR 高产水稻 入田试种
销售:
  - 种子销售额 ¥18亿
  - 海外授权 $12M
研发投入: 营收12%
```
