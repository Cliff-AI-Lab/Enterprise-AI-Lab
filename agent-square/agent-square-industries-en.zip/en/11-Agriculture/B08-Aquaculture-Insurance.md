---
name: 渔业养殖保险
name_en: Aquaculture Insurance
type: Composite Application
industry: Agriculture
apis: [NASA EONET, OpenWeatherMap]
emoji: 🐠
---

# 🐠 渔业养殖保险

## Use Case
海水/淡水养殖的台风/赤潮/病害保险产品设计+理赔。

## Core Capabilities
- 气象指数险
- 病害险
- 理赔快捷
- 行业风险池

## Sample Output
```
【某沿海渔业险 年报】
承保面积: 480万亩
保费: ¥6.8亿 | 赔付 ¥5.2亿
产品:
  - 台风指数险 35%
  - 赤潮/水温 25%
  - 病害险 22%
  - 价格险 18%
快速理赔:
  - 气象指数险 72小时
  - 传统险 平均7天
```
