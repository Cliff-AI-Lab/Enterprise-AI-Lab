---
name: 跨境电商合规
name_en: Cross-border E-commerce Compliance
type: Composite Application
industry: Retail
composed_of: [关务报关员, 电商运营专家, 法律文书审查员]
source_refs: [Cross-Border E-Commerce Specialist, Legal Compliance Checker]
apis: [UK Trade Tariff, ExchangeRate-API, RestCountries]
emoji: 🌐
---

# 🌐 跨境电商合规 Cross-border E-commerce Compliance

## Use Case
Amazon/TikTok Shop/TEMU/SHEIN 卖家的各国税务/产品认证/广告法/数据合规。

## Agent Composition
```
[关务报关员] ← Legal Compliance Checker
[电商运营专家] ← Cross-Border E-Commerce Specialist
[法律文书审查员] ← Legal Document Review
```

## Bound APIs
| API | Purpose |
|-----|------|
| UK Trade Tariff | HS/税率 |
| RestCountries | 各国合规 |
| ExchangeRate-API | 税基折算 |

## 核心工作流
1. **目的国清单**：VAT/IOSS/EPR
2. **产品认证**：CE/FCC/PSE
3. **广告合规**：禁词/比较
4. **数据合规**：GDPR/CCPA
5. **仲裁应对**：A2Z/侵权投诉

## Sample Output
```
【某3C卖家 合规健康度 Q1】
主力市场: 美/欧/日
合规任务:
  ✅ 美国: FCC认证完备, 加州Prop65标签OK
  ✅ 欧盟: CE标识 + GS认证 + 德法EPR注册
  ⚠️ 日本: PSE有效期6个月后过期, 需续
  ⚠️ 英国: UKCA 2028前必须切换 (已启动)
VAT/IOSS:
  - 欧盟IOSS申报 按月, 无滞纳
  - 英国VAT 已注册
  - 日本JCT 账号注册中
广告审核:
  - 本月下架2条违规素材 (绝对化用语)
  - 竞品比较广告已审批
GDPR:
  - Cookie Banner合规
  - 用户删除请求28天内响应
风险清单:
  - 3个SKU专利风险, 已预案
```
