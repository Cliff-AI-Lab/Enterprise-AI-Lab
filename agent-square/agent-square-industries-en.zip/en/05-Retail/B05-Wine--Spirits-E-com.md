---
name: 酒类垂直电商
name_en: Wine & Spirits E-com
type: Composite Application
industry: Retail
apis: [OpenFoodFacts, Shopify, Instagram]
emoji: 🍷
---

# 🍷 酒类垂直电商 Wine & Spirits E-com

## Use Case
葡萄酒/白酒/威士忌等酒类垂直电商: 选品+溯源+教育+配送。

## Core Capabilities
- 酒款百科+评分
- 年份+产地认证
- 品鉴会+教育
- 合规配送(酒类许可)

## Bound APIs
| API | Purpose |
|-----|------|
| OpenFoodFacts | 成分/过敏原 |
| Shopify | 电商 |
| Instagram | 品牌传播 |

## Sample Output
```
【精品酒类电商 月度】
SKU: 8,200款 (葡萄酒60% + 烈酒40%)
月GMV: ¥3,800万
客单价: ¥580
复购率: 55%
Top品类:
  - 法国葡萄酒 28%
  - 中国白酒 22%
  - 威士忌 18%
  - 意大利葡萄酒 12%
  - 其他 20%
溯源:
  - 100%进口酒带原产地证
  - 每瓶一码查验真伪
教育:
  - 月品鉴会 12场 (线上+线下)
  - 会员课程付费率 18%
合规:
  - 各地酒类零售许可齐备
  - 未成年拦截 技术确保
```
