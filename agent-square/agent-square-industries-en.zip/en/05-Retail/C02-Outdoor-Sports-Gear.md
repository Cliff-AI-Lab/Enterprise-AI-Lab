---
name: 户外运动装备
name_en: Outdoor Sports Gear
type: Composite Application
industry: Retail
apis: [Sports APIs, OpenWeatherMap, Instagram]
emoji: ⛺
---

# ⛺ 户外运动装备

## Use Case
户外/露营/徒步垂直电商: 装备清单+场景方案+社群。

## Core Capabilities
- 装备搭配
- 目的地+天气
- 社群+UGC
- 租赁模式

## Sample Output
```
【户外电商 月度】
GMV: ¥1.2亿 | 用户 86万
品类:
  - 帐篷睡袋 32%
  - 服装 28%
  - 厨具 18%
  - 电源 12%
  - 其他 10%
场景营销:
  - 周末露营包 新客转化+28%
  - 徒步季 销量翻倍
社群:
  - UGC月4,200条
  - 线下活动 48场
租赁: 高端装备日租20元起 复用6次以上
```
