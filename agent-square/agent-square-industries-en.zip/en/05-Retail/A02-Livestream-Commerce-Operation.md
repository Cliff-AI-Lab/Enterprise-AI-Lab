---
name: 直播电商闭环
name_en: Livestream Commerce Operation
type: Composite Application
industry: Retail
composed_of: [社交电商运营, 商品定价分析师, 客服智能助手]
source_refs: [Livestream Commerce Coach, Douyin Strategist, Kuaishou Strategist]
apis: [TikTok Display, Instagram, YouTube Data]
emoji: 📺
---

# 📺 直播电商闭环 Livestream Commerce Operation

## Use Case
直播基地/MCN/品牌自播 的排品+话术+流量+复盘全流程。

## Agent Composition
```
[社交电商运营] ← Livestream Commerce Coach (marketing)
[商品定价分析师] ← Financial Analyst
[客服智能助手] ← Customer Service
```

## Bound APIs
| API | Purpose |
|-----|------|
| TikTok Display | 直播间数据 |
| YouTube Data | YouTube Live |
| Stripe/Payment | 订单转化 |

## 核心工作流
1. **排品策略**：引流/利润/常销
2. **脚本+话术**：3小时节奏
3. **投流配合**：千川/星图
4. **实时调整**：停留/互动/转化
5. **复盘优化**：每场拆解

## Sample Output
```
【某美妆品牌 4/17 直播复盘】
时长: 4小时 | 累计观看 28.5万 | 峰值在线 4.2万
GMV: ¥328万 | ROI 3.8x
SKU表现 (Top5):
  1. 精华套装 ¥158万 (48%) 引流款
  2. 口红礼盒 ¥62万
  3. 面膜订阅 ¥38万 ← 利润款
  4. 防晒霜 ¥25万
  5. 眼霜 ¥18万
关键节点:
  - 20:15 "上链接" 冲榜 → 瞬间UV+8千
  - 21:00 达人连麦 助推口红爆单
  - 22:15 福袋抽奖 停留+3分钟
问题:
  - 22:45 客服响应慢, 流失约 12%订单
  - 副播控节奏偏乱, 下次增加排练
下场优化: 冲刺时间前置 + 增加客服 + 换品节奏加快
```
