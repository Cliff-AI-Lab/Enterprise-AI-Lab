---
name: 花艺鲜花速递
name_en: Floral Delivery Service
type: Composite Application
industry: Retail
apis: [OpenRouteService, AfterShip, Instagram]
emoji: 💐
---

# 💐 花艺鲜花速递 Floral Delivery Service

## Use Case
节日鲜花(母亲节/情人节)高峰 + 日常订阅花束的配送运营。

## Core Capabilities
- 节日爆单调度
- 冷链保鲜
- 花艺师资源
- 订阅制运营

## Bound APIs
| API | Purpose |
|-----|------|
| OpenRouteService | 同城配送 |
| AfterShip | 鲜花追踪 |
| Instagram | 花艺作品展示 |

## Sample Output
```
【某鲜花速递 月度】
日均订单: 8,400 (情人节峰值12万)
花艺师: 680名 (全国)
产品:
  - 节日爆款 42%
  - 日常花束 32%
  - 订阅"花伴" 26%
订阅用户: 28万 (月花费 ¥98)
配送:
  - 2小时达 占64%
  - 次日达 36%
  - 鲜花到达完好率 98%
节日运营:
  - 母亲节订单 42万 (备货15天)
  - 提前预热 2周
  - 动态溢价 +15-30%
```
