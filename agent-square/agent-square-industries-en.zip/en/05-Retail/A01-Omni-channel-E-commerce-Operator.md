---
name: 全域电商操盘手
name_en: Omni-channel E-commerce Operator
type: Composite Application
industry: Retail
composed_of: [电商运营专家, 社交电商运营, 商品定价分析师, 客服智能助手]
source_refs: [Growth Hacker, Xiaohongshu Specialist, Douyin Strategist, Customer Service]
apis: [Shopify, Instagram Graph, Open Prices, LibreTranslate]
emoji: 🌏
---

# 🌏 全域电商操盘手 Omni-channel E-commerce Operator

## Use Case
天猫+京东+抖音+小红书+独立站全渠道统一运营: 选品/定价/流量/货品/客服一盘棋。

## Agent Composition
```
[电商运营专家] ← Growth Hacker (marketing)
[社交电商运营] ← Xiaohongshu / Douyin / WeChat Official (marketing)
[商品定价分析师] ← Financial Analyst
[客服智能助手] ← Customer Service
```

## Bound APIs
| API | Purpose |
|-----|------|
| Shopify Admin | 独立站订单/库存 |
| Instagram Graph | IG Shop |
| TikTok Display | TikTok Shop |
| Open Prices | 同SKU竞品比价 |

## 核心工作流
1. **数据中台**：订单/库存/客户打通
2. **分渠道策略**：爆款/长尾
3. **内容矩阵**：短视频+直播+笔记
4. **动态调价**：各平台差异化
5. **一体化客服**：多渠道工单

## Sample Output
```
【全渠道月度GMV战报 2026-04】
总GMV: ¥2,840万 (↑28% YoY)
分渠道:
  - 天猫 38% (¥1,079万) 核心
  - 抖音 22% (¥625万) 增速+82%
  - 京东 18% (¥511万)
  - 独立站 12% (¥341万) 海外+
  - 小红书 6% (¥170万) 种草
  - IG Shop 4% (¥114万)
重点打法:
  - 抖音短视频日更 + 直播周3场
  - 小红书KOC种草 → 天猫收割
  - 独立站订阅制ARPU $85
库存周转: 62天 | 断货SKU 6 (待补)
ROI: 4.2x | 下月目标¥3,200万
```
