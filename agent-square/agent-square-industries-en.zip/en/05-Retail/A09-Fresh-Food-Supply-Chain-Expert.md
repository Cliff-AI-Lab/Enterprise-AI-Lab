---
name: 生鲜供应链专家
name_en: Fresh Food Supply Chain Expert
type: Composite Application
industry: Retail
composed_of: [供应链策略师, 仓储物流协调员, 商品定价分析师, 质量检测员]
source_refs: [Supply Chain Strategist, Studio Operations]
apis: [Open Prices, OpenFoodFacts, AfterShip, OpenWeatherMap]
emoji: 🥬
---

# 🥬 生鲜供应链专家 Fresh Food Supply Chain Expert

## Use Case
生鲜电商/连锁超市: 从源头基地→冷链→前置仓→门店的全程温控+损耗控制。

## Agent Composition
```
[供应链策略师] → 基地/产地直采
[仓储物流协调员] → 冷链调度
[商品定价分析师] → 临期动态降价
[质量检测员] → 入场验收
```

## Bound APIs
| API | Purpose |
|-----|------|
| OpenFoodFacts | 食品信息 |
| Open Prices | 产地价格 |
| OpenWeatherMap | 基地气象 |
| AfterShip | 冷链追踪 |

## 核心工作流
1. **源头直采**：基地合作+标准化
2. **冷链运输**：温度/时间控制
3. **品控入仓**：抽样/理化/农残
4. **动态库存**：货架期管理
5. **临期处理**：降价+配送员优先

## Sample Output
```
【生鲜运营日报 2026-04-17】
进货量: 82吨 (蔬菜 42, 水果 28, 肉蛋奶 12)
损耗率: 3.2% (目标<4%) ✅
分品类:
  - 绿叶菜 6.8% (最高)
  - 苹果 1.2%
  - 鲜肉 2.5%
冷链追踪:
  - 全程温控合格率 99.2%
  - 3次超温预警 (已处置)
临期管理:
  - 当日临期 1,240 SKU
  - 降价清库存 58%
  - 直接报损 4%
基地天气:
  - 山东苹果产区 霜冻预警 → 提前锁单
  - 海南果蔬 暴雨 → 替代产地启用
```
