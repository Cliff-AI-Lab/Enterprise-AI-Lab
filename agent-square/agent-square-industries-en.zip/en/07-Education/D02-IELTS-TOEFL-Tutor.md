---
name: 雅思托福陪练
name_en: IELTS/TOEFL Tutor
type: Composite Application
industry: Education
apis: [HuggingFace, Dictionary API]
emoji: 🗣️
---

# 🗣️ 雅思托福陪练

## Use Case
留学英语考试的AI口语陪练+写作批改+模考。

## Sample Output
```
【某语培 年度】
学员: 28万 (雅思18+托福10)
AI口语: 日均互动 42万次
成绩提升:
  - 雅思平均+1.2分
  - 托福平均+18分
写作批改:
  - AI初批 + 外教精批
  - 24小时出分
学费: ¥3,800-18,000
```
