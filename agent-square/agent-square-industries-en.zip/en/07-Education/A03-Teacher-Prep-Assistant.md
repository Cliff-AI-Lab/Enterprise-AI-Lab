---
name: 教研备课助手
name_en: Teacher Prep Assistant
type: Composite Application
industry: Education
composed_of: [课程设计师, 学术论文助手, 知识问答专家]
source_refs: [Corporate Training Designer, Narratologist, Psychologist]
apis: [Open Library, CrossRef, Wikipedia]
emoji: 📝
---

# 📝 教研备课助手 Teacher Prep Assistant

## Use Case
中小学/大学教师备课: 教案生成、习题套配、多媒体素材。

## Agent Composition
```
[课程设计师] ← Corporate Training Designer
[学术论文助手] ← Narratologist
[知识问答专家] ← Psychologist
```

## Bound APIs
| API | Purpose |
|-----|------|
| Open Library | 教材参考 |
| CrossRef | 学术支撑 |
| Wikipedia | 背景知识 |
| Unsplash | Free图片 |

## 核心工作流
1. **知识点解析**：重难点
2. **教案草稿**：导入+新课+练习
3. **题库生成**：多难度阶梯
4. **多媒体**：图/视频/互动
5. **差异化**：学困/中等/尖子

## Sample Output
```
【初二物理"浮力"教案】
课时: 2 × 45分钟
教学目标:
  - 理解阿基米德原理 (知识)
  - 计算浮力大小 (技能)
  - 感受科学探究过程 (情感)
课堂设计:
  导入 (5分) - 鸡蛋浮沉实验 (学生预测)
  新课 (25分) - 概念讲授 + 演示
  练习 (10分) - 梯度习题 (基础/变式/拓展)
  小结 (5分) - 思维导图
题库 (20道):
  - 基础 8题 (公式直接套用)
  - 提高 8题 (结合密度/受力)
  - 拓展 4题 (船吃水线/潜艇)
教具清单: 弹簧测力计, 铁块, 盐水, 鸡蛋 (已准备)
配套视频: <神秘浮沉> (3分钟动画)
```
