---
name: 学生生涯规划
name_en: Student Career Planner
type: Composite Application
industry: Education
composed_of: [留学顾问, 知识问答专家, 消费者洞察专家]
source_refs: [Study Abroad Advisor, Psychologist, Trend Researcher]
apis: [Hipolabs Universities, RestCountries, NewsAPI]
emoji: 🎯
---

# 🎯 学生生涯规划 Student Career Planner

## Use Case
高中/大学生的专业选择、名校申请、职业发展前瞻规划。

## Agent Composition
```
[留学顾问] ← Study Abroad Advisor
[知识问答专家] ← Psychologist
[消费者洞察专家] ← Trend Researcher
```

## Bound APIs
| API | Purpose |
|-----|------|
| Hipolabs Universities | 院校库 |
| RestCountries | 就业国家 |
| NewsAPI | 行业趋势 |

## 核心工作流
1. **兴趣能力测评**：霍兰德/MBTI
2. **专业匹配**：价值观+学科
3. **院校列表**：冲稳保
4. **职业前景**：10年趋势
5. **行动路径**：每学年动作

## Sample Output
```
【高二 李同学 生涯规划报告】
测评结论:
  霍兰德: IAS (研究型+艺术+社会型)
  MBTI: INFJ (倡导者)
  学科优势: 生物/化学/英语
推荐专业方向:
  1. 生物医学 / 药学 (匹配度92%)
  2. 心理学 / 认知科学 (88%)
  3. 公共卫生 (82%)
目标院校:
  国内: 北大医学 / 浙大药学 / 复旦公卫
  海外: JHU / UCLA 生物医学
  保底: 上交药学 / UMD
10年职业前景:
  - 医药新药研发: AI制药正在崛起
  - 神经科学: 脑机接口热度持续上升
  - 公共卫生: 全球老龄化推动需求
行动路径:
  高二: 夯实数理化 + 生物竞赛
  高三: 冲刺高考 + 强基选拔
  大学: 大二实验室, 大三交流, 大四申研
  毕业后: 硕博连读 or PhD
```
