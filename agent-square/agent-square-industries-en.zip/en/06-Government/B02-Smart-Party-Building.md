---
name: 智慧党建
name_en: Smart Party Building
type: Composite Application
industry: Government
composed_of: [课程设计师, 公共数据分析师, 舆情监控员, 文档生成专家]
source_refs: [Corporate Training Designer, Content Creator, Executive Summary Generator]
apis: [NewsAPI, LibreTranslate, PDFMonkey]
emoji: 🇨🇳
---

# 🇨🇳 智慧党建 Smart Party Building

## Use Case
党建信息化: 党员学习、组织生活、三会一课、在线考核+推送。

## Agent Composition
```
[课程设计师] ← Corporate Training Designer
[公共数据分析师] ← Analytics Reporter
[舆情监控员] → 舆情辅助学习
[文档生成专家] ← Document Generator
```

## Bound APIs
| API | Purpose |
|-----|------|
| NewsAPI | 时政学习 |
| PDFMonkey | 组织生活记录 |
| 在线学习平台 | 课程 |

## 核心工作流
1. **组织架构**：党组织电子化
2. **学习打卡**：日/周/月
3. **考试测评**：时政+党章
4. **会议记录**：三会一课存档
5. **党性分析**：民主评议

## Sample Output
```
【某市智慧党建 年报】
基层党组织: 28,400个 | 党员 68万
学习:
  - 人均学时 124小时/年 (达标)
  - 在线课程 480门
  - 月打卡率 96%
组织生活:
  - 三会一课 按时召开率 98%
  - 主题党日 平均4.2次/支部/年
  - 民主评议 完成率 100%
主题教育:
  - 某主题党日覆盖 68万党员
  - 观看直播 220万人次
时政学习:
  - 重要讲话第一时间推送
  - 学习强国同步
活动:
  - 为群众办实事 8,400件
  - 结对帮扶 12,000户
```
