---
name: 12345热线智能
name_en: Citizen Hotline AI
type: Composite Application
industry: Government
composed_of: [舆情监控员, 客服智能助手, 政务翻译官, 公共数据分析师]
source_refs: [Customer Service, Government Digital Presales, Language Translator]
apis: [LibreTranslate, NewsAPI, Data.gov]
emoji: 📞
---

# 📞 12345热线智能 Citizen Hotline AI

## Use Case
市民服务热线智能化: 工单自动分派、情绪识别、满意度跟踪、热点话题发现。

## Agent Composition
```
[客服智能助手] ← Customer Service
[舆情监控员] ← Reddit Community Builder
[政务翻译官] ← Language Translator
[公共数据分析师] ← Analytics Reporter
```

## Bound APIs
| API | Purpose |
|-----|------|
| LibreTranslate | 方言/外语对接 |
| NewsAPI | 同期热点交叉 |
| Data.gov CKAN | 政策库匹配 |

## 核心工作流
1. **接听**：语音→文本+意图识别
2. **分派**：按街道/部门/紧急度
3. **跟踪**：SLA工单闭环
4. **情绪**：愤怒→人工升级
5. **数据**：热点词/办结率

## Sample Output
```
【12345热线 月度看板】
来电量: 18.2万 | 受理工单 12.4万
平均响应: 8秒 | 办结率: 96.8%
工单分布:
  - 市容环卫 18%
  - 物业投诉 15%
  - 交通出行 12%
  - 拆迁安置 10%
  - 民生救助 8% ...
情绪预警: 234通高愤怒已人工介入
热点突发:
  - 4/14 某小区电梯事故 → 集中来电420+
  - 应急响应: 1小时内市级督办
方言覆盖: 普通话+粤/闽/川共识别率95%
外语: 英/日/韩/俄 同步接入
```
