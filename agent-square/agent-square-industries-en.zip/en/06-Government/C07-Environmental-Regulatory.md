---
name: 生态环境监管
name_en: Environmental Regulatory
type: Composite Application
industry: Government
apis: [EPA Envirofacts, OpenAQ, NASA EONET]
emoji: 🌿
---

# 🌿 生态环境监管

## Use Case
生态环境局的污染源监管+执法+公众服务。

## Sample Output
```
【某市生态环境 月报】
监管企业: 12,400家 (重点2,800)
执法:
  - 现场执法 480次
  - 立案查处 42起
  - 罚款 ¥280万
污染指数:
  - PM2.5 均值 32 μg/m³
  - 水环境优良 82%
公众:
  - 举报受理 1,200件
  - 办结率 98%
```
