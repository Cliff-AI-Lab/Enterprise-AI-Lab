---
name: 特种运输
name_en: Specialized Transport
type: Composite Application
industry: Logistics
apis: [OpenRouteService, OpenWeatherMap]
emoji: 🏗️
---

# 🏗️ 特种运输

## Use Case
大件+超限运输: 风电叶片/石化设备/盾构机等的专用车辆+路线报批。

## Sample Output
```
【某特种运输 年度】
项目: 380个
典型:
  - 海上风电叶片(100m)
  - 石化反应器(800吨)
  - 地铁盾构机
单项目周期: 30-90天
路线审批:
  - 每省公路局 + 跨桥梁评估
  - 平均3-5省协调
安全: 0事故 | 客户98%满意
```
