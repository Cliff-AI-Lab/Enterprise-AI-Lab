---
name: 航运调度
name_en: Shipping Line Dispatcher
type: Composite Application
industry: Logistics
composed_of: [运力调度员, 路径规划师, 外汇交易助手, 关务报关员]
source_refs: [Project Shepherd, Geographer]
apis: [OpenRouteService, ExchangeRate-API, OpenWeatherMap]
emoji: 🚢
---

# 🚢 航运调度 Shipping Line Dispatcher

## Use Case
航运公司船队调度: 船期规划、燃油优化、航线绕行、空箱调运。

## Agent Composition
```
[运力调度员] ← Project Shepherd
[路径规划师] ← Geographer
[外汇交易助手] → 多币种结算
[关务报关员] → 签证港
```

## Bound APIs
| API | Purpose |
|-----|------|
| OpenRouteService | 海运路径 |
| OpenWeatherMap | 海况/台风 |
| ExchangeRate-API | 港费折算 |

## 核心工作流
1. **船队状态**：在航/靠港/检修
2. **航线规划**：燃油+时效
3. **货量匹配**：舱位利用率
4. **绕行决策**：海盗/恶劣天气
5. **空箱调运**：全球平衡

## Sample Output
```
【某航运公司 周运营】
船队: 48艘 (集装箱/散货/油轮)
在航: 36 | 靠港 8 | 检修 4
本周重大决策:
  1. 红海绕好望角 (增3-4周, 成本+30%)
     → 接受30%溢价运费 (红海溢价效应)
  2. 太平洋航线 避开台风"伟伯" 绕行+1天
  3. 空箱回运: 北美→亚洲 运价¥300 (补贴30%)
舱位利用率: 85% (行业良好水平)
燃油优化:
  - 减速航行 节省18%油耗
  - LNG船 占比↑ 碳排降低25%
财务:
  - 周营收 $180M
  - 均单航次利润率 22%
```
